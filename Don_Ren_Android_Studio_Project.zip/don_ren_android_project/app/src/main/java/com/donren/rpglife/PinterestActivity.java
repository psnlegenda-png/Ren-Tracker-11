package com.donren.rpglife;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.view.WindowManager;

/** Isolated browser: intentionally NO privileged JavaScript bridge. */
public final class PinterestActivity extends Activity {
  private WebView browser;
  @Override public void onCreate(Bundle b){super.onCreate(b);
    String url=getIntent().getStringExtra("pinBoard");
    if(url==null || !url.startsWith("https://ru.pinterest.com/")){finish();return;}
    browser=new WebView(this);browser.setBackgroundColor(Color.WHITE);
    WebSettings s=browser.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setAllowFileAccess(false);s.setSupportMultipleWindows(false);
    browser.setWebViewClient(new WebViewClient(){
      @Override public boolean shouldOverrideUrlLoading(WebView w,android.webkit.WebResourceRequest request){
        Uri u=request.getUrl();
        if("https".equals(u.getScheme())&&(u.getHost().equals("pinterest.com")||u.getHost().endsWith(".pinterest.com")))return false;
        return true;
      }
    });
    setContentView(browser);
    browser.loadUrl(url);
  }
  @Override public void onBackPressed(){if(browser!=null&&browser.canGoBack())browser.goBack();else super.onBackPressed();}
  @Override protected void onDestroy(){if(browser!=null){browser.destroy();browser=null;}super.onDestroy();}
}
