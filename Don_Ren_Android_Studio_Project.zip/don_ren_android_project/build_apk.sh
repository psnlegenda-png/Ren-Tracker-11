#!/usr/bin/env sh
set -eu
if command -v gradle >/dev/null 2>&1; then
  gradle assembleDebug
  echo 'APK: app/build/outputs/apk/debug/app-debug.apk'
else
  echo 'Gradle is not installed in PATH. Open project in Android Studio and use Build APK(s).' >&2
  exit 1
fi
