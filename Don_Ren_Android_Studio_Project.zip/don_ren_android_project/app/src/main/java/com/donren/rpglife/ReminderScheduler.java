package com.donren.rpglife;

import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.HashSet;
import java.util.Set;

final class ReminderScheduler {
    static final String CHANNEL = "donren_planner_01";
    private static final String PREFS="don_ren_native_reminders";
    static void ensureChannel(Context context) {
        NotificationManager nm=(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel(CHANNEL,"Ежедневник ДОН РЕН",NotificationManager.IMPORTANCE_HIGH));
    }
    private static PendingIntent pending(Context c, String id, String title, String repeat, long at) {
        Intent i = new Intent(c, ReminderReceiver.class);
        i.setAction("com.donren.rpglife.REMIND."+id);
        i.putExtra("id",id);
        i.putExtra("title",title);
        i.putExtra("repeat",repeat);
        i.putExtra("at",at);
        return PendingIntent.getBroadcast(c, id.hashCode(), i, PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    }
    static void schedule(Context c,String id,String title,String repeat,long at) {
        if (at<=System.currentTimeMillis())return;
        AlarmManager m=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        m.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pending(c,id,title,repeat,at));
    }
    private static void cancel(Context c,String id) {
        Intent i=new Intent(c,ReminderReceiver.class);
        i.setAction("com.donren.rpglife.REMIND."+id);
        PendingIntent pi=PendingIntent.getBroadcast(c,id.hashCode(),i,PendingIntent.FLAG_NO_CREATE|PendingIntent.FLAG_IMMUTABLE);
        if(pi!=null){((AlarmManager)c.getSystemService(Context.ALARM_SERVICE)).cancel(pi);pi.cancel();}
    }
    static void sync(Context c,String json){
        try {
            SharedPreferences prefs=c.getSharedPreferences(PREFS,Context.MODE_PRIVATE);
            Set<String> old=prefs.getStringSet("ids",new HashSet<>());
            for(String id:old)cancel(c,id);
            JSONArray items=new JSONArray(json);
            JSONArray accepted=new JSONArray();Set<String> ids=new HashSet<>();
            for(int n=0;n<items.length()&&n<300;n++){
                JSONObject o=items.optJSONObject(n);if(o==null)continue;
                String id=o.optString("id","");String title=o.optString("title","");String repeat=o.optString("repeat","none");long at=o.optLong("at",0);
                if(id.isEmpty()||id.length()>100||title.isEmpty()||at<=System.currentTimeMillis()||at>System.currentTimeMillis()+366L*86400000L)continue;
                schedule(c,id,title,repeat,at);ids.add(id);accepted.put(o);
            }
            prefs.edit().putStringSet("ids",ids).putString("tasks",accepted.toString()).apply();
        }catch(Exception ignored){}
    }
    static void restore(Context c){
        try {String saved=c.getSharedPreferences(PREFS,Context.MODE_PRIVATE).getString("tasks","[]");
          JSONArray a=new JSONArray(saved);
          for(int n=0;n<a.length();n++){
            JSONObject o=a.optJSONObject(n);if(o==null)continue;
            long at=o.optLong("at",0);String repeat=o.optString("repeat","none");
            if(at<=System.currentTimeMillis()&&(repeat.equals("daily")||repeat.equals("weekly"))){
               java.util.Calendar cal=java.util.Calendar.getInstance();cal.setTimeInMillis(at);
               do{cal.add(java.util.Calendar.DAY_OF_YEAR,repeat.equals("daily")?1:7);}while(cal.getTimeInMillis()<=System.currentTimeMillis());at=cal.getTimeInMillis();
            }
            schedule(c,o.optString("id"),o.optString("title"),repeat,at);
          }
        }catch(Exception ignored){}
    }
    static void test(Context c){schedule(c,"test-"+System.currentTimeMillis(),"Проверка уведомлений: всё работает", "none",System.currentTimeMillis()+60000);}
}
