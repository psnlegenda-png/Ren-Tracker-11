package com.donren.rpglife;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import java.util.Calendar;

public final class ReminderReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        if (intent == null) return;
        String id = intent.getStringExtra("id");
        if (id == null) return;
        String title = intent.getStringExtra("title");
        String repeat = intent.getStringExtra("repeat");
        ReminderScheduler.ensureChannel(context);
        // POST_NOTIFICATIONS permission can be denied; keep existing schedules and do not crash.
        if (Build.VERSION.SDK_INT < 33 || context.checkSelfPermission("android.permission.POST_NOTIFICATIONS") == android.content.pm.PackageManager.PERMISSION_GRANTED) {
            Intent launch = new Intent(context, MainActivity.class);
            PendingIntent tap = PendingIntent.getActivity(context, 991, launch, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            Notification notification = new Notification.Builder(context, ReminderScheduler.CHANNEL)
                 .setSmallIcon(android.R.drawable.ic_popup_reminder)
                 .setContentTitle("📒 ДОН РЕН · Ежедневник")
                 .setContentText(title != null ? title : "Время выполнить задачу")
                 .setContentIntent(tap)
                 .setAutoCancel(true)
                 .setWhen(System.currentTimeMillis())
                 .build();
            ((NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE)).notify(id.hashCode(), notification);
        }
        if ("daily".equals(repeat) || "weekly".equals(repeat)) {
            long at = intent.getLongExtra("at", System.currentTimeMillis());
            Calendar cal=Calendar.getInstance();cal.setTimeInMillis(at);
            do { cal.add(Calendar.DAY_OF_YEAR, "daily".equals(repeat)?1:7); } while (cal.getTimeInMillis() <= System.currentTimeMillis());
            ReminderScheduler.schedule(context,id,title,repeat,cal.getTimeInMillis());
        }
    }
}
