package com.donren.rpglife;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.WindowInsets;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import android.webkit.ValueCallback;
import androidx.webkit.WebViewAssetLoader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public final class MainActivity extends Activity {
    private static final int REQUEST_OPEN_JSON = 404;
    private static final int REQUEST_SAVE_JSON = 405;
    private static final String APP_URL = "https://appassets.androidplatform.net/assets/index.html";
    private WebView webView;
    private ValueCallback<Uri[]> pendingFile;
    private String pendingExport;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(11,16,27));
        getWindow().setNavigationBarColor(Color.rgb(11,16,27));
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(11,16,27));
        // Content never overlaps status bar, camera cutout or gesture navigation.
        if (Build.VERSION.SDK_INT >= 30) {
            getWindow().setDecorFitsSystemWindows(false);
            webView.setOnApplyWindowInsetsListener((view, windowInsets) -> {
                android.graphics.Insets insets = windowInsets.getInsets(
                    WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                view.setPadding(0, insets.top, 0, insets.bottom);
                return windowInsets;
            });
        }
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true); // Selected JSON via Android file picker
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setSupportMultipleWindows(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setMediaPlaybackRequiresUserGesture(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
            .build();
        webView.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                // Never navigate the privileged WebView to untrusted web content.
                return !"appassets.androidplatform.net".equals(request.getUrl().getHost());
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view,
                       ValueCallback<Uri[]> filePathCallback, FileChooserParams params) {
                if (pendingFile != null) pendingFile.onReceiveValue(null);
                pendingFile = filePathCallback;
                try {
                    Intent pick = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    pick.addCategory(Intent.CATEGORY_OPENABLE);
                    pick.setType("application/json");
                    startActivityForResult(pick, REQUEST_OPEN_JSON);
                    return true;
                } catch (Exception ex) {
                    pendingFile.onReceiveValue(null);
                    pendingFile = null;
                    return false;
                }
            }
        });
        // Exposed only to bundled, local HTML; remote navigations are blocked.
        webView.addJavascriptInterface(new NativeBridge(), "DonRenNative");
        webView.loadUrl(APP_URL);
    }

    public final class NativeBridge {
        @JavascriptInterface public void exportJson(String json) {
            if (json == null || json.length() > 8000000) return;
            runOnUiThread(() -> {
                pendingExport = json;
                Intent save = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                save.addCategory(Intent.CATEGORY_OPENABLE);
                save.setType("application/json");
                save.putExtra(Intent.EXTRA_TITLE, "DON_REN_Tracker.json");
                try { startActivityForResult(save, REQUEST_SAVE_JSON); }
                catch (Exception ex) { pendingExport=null; toast("Не удалось открыть сохранение"); }
            });
        }
        @JavascriptInterface public void minimizeApp() {
            runOnUiThread(() -> moveTaskToBack(true));
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_OPEN_JSON) {
            if (pendingFile != null) {
                Uri uri = resultCode == RESULT_OK && data != null ? data.getData() : null;
                pendingFile.onReceiveValue(uri == null ? null : new Uri[]{uri});
                pendingFile = null;
            }
        } else if (requestCode == REQUEST_SAVE_JSON) {
            if (resultCode == RESULT_OK && data != null && data.getData()!=null && pendingExport != null) {
                try (OutputStream out = getContentResolver().openOutputStream(data.getData())) {
                    if (out == null) throw new Exception("null stream");
                    out.write(pendingExport.getBytes(StandardCharsets.UTF_8));
                    toast("Резервная копия сохранена");
                } catch (Exception ex) { toast("Ошибка сохранения файла"); }
            }
            pendingExport = null;
        }
    }
    private void toast(String text) { Toast.makeText(this, text, Toast.LENGTH_SHORT).show(); }
    @Override public void onBackPressed() {
        if (webView == null) {super.onBackPressed();return;}
        webView.evaluateJavascript("window.donRenBack && window.donRenBack()", null);
    }
    @Override protected void onDestroy() {
        if (webView != null) { webView.removeJavascriptInterface("DonRenNative"); webView.destroy(); webView=null; }
        super.onDestroy();
    }
}
