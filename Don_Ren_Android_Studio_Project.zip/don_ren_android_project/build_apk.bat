@echo off
chcp 65001 > nul
where gradle > nul 2>&1
if errorlevel 1 (
  echo ERROR: Gradle command line was not found.
  echo Open this project in Android Studio, wait for Gradle Sync, then:
  echo Build -^> Build Bundle(s) / APK(s) -^> Build APK(s).
  pause
  exit /b 1
)
gradle assembleDebug
if errorlevel 1 (echo Build failed & pause & exit /b 1)
echo APK: app\build\outputs\apk\debug\app-debug.apk
pause
